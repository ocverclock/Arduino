#pragma once
#include <stdint.h>
#include <cstring>
class EEPROMClass {
 public:
  unsigned char data[1024];
  EEPROMClass() { std::memset(data,0xff,sizeof(data)); }
  template<class T> void put(int p, const T &t) {std::memcpy(data+p,&t,sizeof(T));}
  template<class T> void get(int p, T &t) {std::memcpy(&t,data+p,sizeof(T));}
};
extern EEPROMClass EEPROM;
