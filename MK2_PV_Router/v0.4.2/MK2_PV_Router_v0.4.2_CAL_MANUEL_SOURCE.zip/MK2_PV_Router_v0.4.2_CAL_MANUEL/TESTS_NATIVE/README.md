# Test unitaire natif de l'EEPROM (aucun materiel requis)

Depuis le dossier principal :

```sh
g++ -std=c++17 -Wall -Wextra -Werror -I TESTS_NATIVE -I FIRMWARE_MK2_REV2_1A/Mk2_fasterControl_Full FIRMWARE_MK2_REV2_1A/Mk2_fasterControl_Full/mk2_calibration.cpp TESTS_NATIVE/test.cpp -o /tmp/mk2_cal_test && /tmp/mk2_cal_test
```

Ce test simule l'EEPROM et ne remplace pas un build AVR ni un test électrique.
