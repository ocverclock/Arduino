#include "EEPROM.h"
#include "mk2_calibration.h"
#include <cassert>
#include <cstdio>
#include <cstring>
EEPROMClass EEPROM;
int main(){
 using namespace Mk2Calibration;
 begin();
 assert(voltageGain()==1000 && gridGain()==1000 && ct2Gain()==1000);
 rememberRaw(19850,350,1800);
 assert(applyVoltage(19850)==19850);
 uint8_t snap[1024];std::memcpy(snap,EEPROM.data,1024);
 assert(!setGain('V',649) && !setGain('V',1501) && !setGain('X',1000));
 assert(std::memcmp(snap,EEPROM.data,1024)==0);
 // Simulated ESP live preview must NEVER touch AVR EEPROM.
 double preview=198.5*1.134; assert(preview>225.08 && preview<225.11);
 assert(std::memcmp(snap,EEPROM.data,1024)==0);
 assert(setGain('V',1134));assert(voltageGain()==1134);
 assert(applyVoltage(19850)==22510);
 assert(setGain('G',1111));assert(applyGrid(350)==389);
 assert(setGain('C',1250));assert(applyCt2(1800)==2250);
 begin(); // persistent EEPROM
 assert(voltageGain()==1134 && gridGain()==1111 && ct2Gain()==1250);
 reset();assert(voltageGain()==1000 && gridGain()==1000 && ct2Gain()==1000);
 std::puts("SUCCESS: EEPROM gains/limits/preview persistence tests");
}
