# MK2 PV Router v0.4.2 — Calibration manuelle, protocole UART

Cette version **part du firmware v0.4.1** et conserve les broches, le controle de chauffe et Optiboot.

- Compilation à utiliser pour le routeur actif : `pio run -e autonomous_power` (triac activé à la compilation, **comportement électrique non qualifié**).
- `autonomous_review` garde le triac inhibé pour tests de laboratoire.
- `@CAL` : lit les gains enregistrés en millièmes et les dernières mesures brutes.
- `@CAL SET V 1134` : règle directement le gain tension à x1,134 et l'enregistre dans l'EEPROM.
- `@CAL SET GRID 1000` : gain CT1 x1,000.
- `@CAL SET CT2 1000` : gain CT2 x1,000.
- Valeurs admises : 650 à 1500. Confirmation sous forme `@ACK CAL SET V=1134`.
- `@CAL RESET` et les anciennes commandes de calibration à référence (`@CAL V`, `@CAL GRID`, `@CAL CT2`) sont conservées pour compatibilité.
- EEPROM à adresse 64, ne pas modifier les champs historiques LIMIT et WAIT. Pas d'écriture EEPROM tant que l'ESP ne transmet pas SET.
- La calibration corrige les valeurs de télémétrie et le calcul d'énergie à partir de CT2, **pas l'algorithme énergétique interne**. Aucun réglage de phase de CT1 n'est fourni.
- Pour une mise à jour **via Optiboot**, utiliser uniquement `.pio/build/autonomous_power/firmware.hex` (NE PAS fusionner avec Optiboot).
- Pour une programmation de secours **par ISP**, il est possible de fusionner le HEX applicatif avec l'Optiboot officiel à 0x7E00 et de vérifier les fusibles.
- Vérification du pilotage de chauffe, des protections, du câblage, de l'isolation du secteur et des mesures requise avant mise en service.
