#pragma once
#include <stdint.h>

// EEPROM calibration of *telemetry* (not the energy bucket or triac timings).
// Permille gains, separately for voltage, CT1/grid power and CT2/diversion power.
namespace Mk2Calibration {
void begin();
void rememberRaw(int16_t voltageCenti, int16_t gridW, int16_t ct2W);
int16_t applyVoltage(int16_t rawCenti);
int16_t applyGrid(int16_t rawW);
int16_t applyCt2(int16_t rawW);
bool setGain(char channel, uint16_t permille);
bool calibrateVoltage(uint16_t referenceDeciV);
bool calibrateGrid(uint16_t referenceW);
bool calibrateCt2(uint16_t referenceW);
void reset();
uint16_t voltageGain();
uint16_t gridGain();
uint16_t ct2Gain();
int16_t rawVoltage();
int16_t rawGrid();
int16_t rawCt2();
}
