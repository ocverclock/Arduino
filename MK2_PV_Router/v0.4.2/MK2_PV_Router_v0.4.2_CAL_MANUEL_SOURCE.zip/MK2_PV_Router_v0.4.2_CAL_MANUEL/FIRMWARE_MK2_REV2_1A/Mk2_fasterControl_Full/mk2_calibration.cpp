// MK2 0.4.0: calibration persisting in a separate EEPROM area.
// NOTE: grid and CT2 calibration corrects reported W/Wh ONLY.
#include "mk2_calibration.h"
#include <Arduino.h>
#include <EEPROM.h>
namespace Mk2Calibration {
namespace {
constexpr uint16_t MAGIC = 0x4C40;
constexpr int ADDRESS = 64;  // existing LIMIT at 0; WAIT at 16
constexpr uint16_t MIN_GAIN = 650;  // allow 0.650x - 1.500x
constexpr uint16_t MAX_GAIN = 1500;
struct CalData { uint16_t magic; uint16_t voltage; uint16_t grid; uint16_t ct2; uint16_t checksum; };
CalData state{MAGIC, 1000, 1000, 1000, 0};
int16_t rawV = 0, rawG = 0, rawC = 0;
uint16_t checksum(const CalData &d) {
  return static_cast<uint16_t>(d.magic ^ d.voltage ^ d.grid ^ d.ct2 ^ 0x8F23U);
}
bool valid(uint16_t x) { return x >= MIN_GAIN && x <= MAX_GAIN; }
void save() { state.checksum = checksum(state); EEPROM.put(ADDRESS, state); }
int16_t apply(int16_t value, uint16_t gain) {
  const int32_t product = static_cast<int32_t>(value) * gain;
  const int32_t result = (product >= 0 ? product + 500 : product - 500) / 1000;
  if (result > INT16_MAX) return INT16_MAX;
  if (result < INT16_MIN) return INT16_MIN;
  return static_cast<int16_t>(result);
}
uint16_t gainFor(uint32_t reference, uint32_t measured) {
  if (measured == 0) return 0;
  const uint32_t g = (reference * 1000UL + measured / 2U) / measured;
  return (g <= UINT16_MAX) ? static_cast<uint16_t>(g) : 0;
}
}
void begin() {
  CalData read{}; EEPROM.get(ADDRESS, read);
  if (read.magic == MAGIC && read.checksum == checksum(read) &&
      valid(read.voltage) && valid(read.grid) && valid(read.ct2)) {
    state = read;
  } else {
    reset();
  }
}
void rememberRaw(int16_t voltageCenti, int16_t gridW, int16_t ct2W) {
  rawV = voltageCenti; rawG = gridW; rawC = ct2W;
}
int16_t applyVoltage(int16_t x) { return apply(x, state.voltage); }
int16_t applyGrid(int16_t x) { return apply(x, state.grid); }
int16_t applyCt2(int16_t x) { return apply(x, state.ct2); }
// New manual mode: accepts only explicit 0.650..1.500 gain in permille.
// Preview is calculated by ESP, not persisted or applied before SET.
bool setGain(char channel, uint16_t permille) {
  if (!valid(permille)) return false;
  uint16_t *target = nullptr;
  switch (channel) {
    case 'V': target = &state.voltage; break;
    case 'G': target = &state.grid; break;
    case 'C': target = &state.ct2; break;
    default: return false;
  }
  if (*target != permille) { *target = permille; save(); }
  return true;
}
bool calibrateVoltage(uint16_t referenceDeciV) {
  if (referenceDeciV < 1800 || referenceDeciV > 2600 || rawV < 15000) return false;
  const uint16_t gain = gainFor(static_cast<uint32_t>(referenceDeciV) * 10U, static_cast<uint16_t>(rawV));
  if (!valid(gain)) return false;
  state.voltage = gain; save(); return true;
}
bool calibrateGrid(uint16_t referenceW) {
  if (referenceW < 100 || referenceW > 10000 || rawG < 100) return false;
  const uint16_t gain = gainFor(referenceW, static_cast<uint16_t>(rawG));
  if (!valid(gain)) return false;
  state.grid = gain; save(); return true;
}
bool calibrateCt2(uint16_t referenceW) {
  if (referenceW < 100 || referenceW > 6000 || rawC < 100) return false;
  const uint16_t gain = gainFor(referenceW, static_cast<uint16_t>(rawC));
  if (!valid(gain)) return false;
  state.ct2 = gain; save(); return true;
}
void reset() { state = {MAGIC, 1000, 1000, 1000, 0}; save(); }
uint16_t voltageGain() { return state.voltage; }
uint16_t gridGain() { return state.grid; }
uint16_t ct2Gain() { return state.ct2; }
int16_t rawVoltage() { return rawV; }
int16_t rawGrid() { return rawG; }
int16_t rawCt2() { return rawC; }
}
