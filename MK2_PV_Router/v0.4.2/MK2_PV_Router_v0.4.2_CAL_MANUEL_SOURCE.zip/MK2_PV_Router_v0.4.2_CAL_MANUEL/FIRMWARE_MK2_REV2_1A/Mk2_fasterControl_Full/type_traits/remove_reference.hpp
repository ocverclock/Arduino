
// ArduinoJson - https://arduinojson.org
// Copyright © 2014-2024, Benoit BLANCHON
// MIT License


#pragma once


// A meta-function that return the type T without the reference modifier.
template< typename T >
struct remove_reference {
  using type = T;
};
template< typename T >
struct remove_reference<T&> {
  using type = T;
};


template <typename T>
using remove_reference_t = typename remove_reference<T>::type;

