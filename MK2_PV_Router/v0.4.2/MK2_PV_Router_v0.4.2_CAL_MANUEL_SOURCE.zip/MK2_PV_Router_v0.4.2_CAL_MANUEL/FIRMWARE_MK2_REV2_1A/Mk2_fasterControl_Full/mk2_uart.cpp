// MK2 PV Router v0.3.9 - controle UART + animations attente solaire.
// Toutes les commandes qui repondent ACK modifient l'etat reel du controleur.
#include "mk2_uart.h"
#include "mk2_shared_state.h"
#include "mk2_wait.h"
#include "mk2_calibration.h"
#include <EEPROM.h>
#include <stdio.h>
#include <string.h>
namespace Mk2Uart {
namespace {
Mk2::Controller ctrl;
// N'accepte que les consignes nominales et limites explicites en EEPROM.
// Format EEPROM v0.3.8 volontairement distinct du stockage en W de la v0.3.7.
struct Stored {uint16_t magic; uint8_t limitPct; uint8_t reserved; uint16_t check;};
constexpr uint16_t storageMagic=0x4B38;
uint16_t checkStored(const Stored &s) {
  return static_cast<uint16_t>(s.magic ^ s.limitPct ^ 0xA55A);
}
void restore() {
  Stored s{}; EEPROM.get(0,s);
  if(s.magic==storageMagic && s.check==checkStored(s) && s.limitPct<=100)
    ctrl.setLimitPercent(s.limitPct);
}
void save() {
  const Stored s{storageMagic,ctrl.limitPct,0,
                 static_cast<uint16_t>(storageMagic ^ ctrl.limitPct ^ 0xA55A)};
  EEPROM.put(0,s);
}
// Zone EEPROM distincte : la sauvegarde de LIMIT de v0.3.8 est preservee.
// La validation par magic + checksum rejette les EEPROM vierges ou corrompues.
struct StoredWait { uint16_t magic; uint8_t style; uint8_t reserved; uint16_t check; };
constexpr uint16_t waitMagic = 0x4B39;
constexpr int waitAddress = 16;
uint8_t selectedWaitStyle = 0;
bool previewEnabled = false;
uint32_t previewSince = 0;
uint16_t checkWait(const StoredWait &s) {
  return static_cast<uint16_t>(s.magic ^ s.style ^ 0x5AB5U);
}
void restoreWait() {
  selectedWaitStyle = 0;
  StoredWait s{}; EEPROM.get(waitAddress, s);
  if (s.magic == waitMagic && s.check == checkWait(s) && s.style < Mk2Wait::styles)
    selectedWaitStyle = s.style;
}
void saveWait() {
  const StoredWait s{waitMagic, selectedWaitStyle, 0,
                      static_cast<uint16_t>(waitMagic ^ selectedWaitStyle ^ 0x5AB5U)};
  EEPROM.put(waitAddress, s);
}
void printWait() {
  Serial.print(F("@WAIT STYLE=")); Serial.print(selectedWaitStyle);
  Serial.print(F(" NAME=")); Serial.println(Mk2Wait::name(selectedWaitStyle));
}
char rx[48]{};uint8_t rxLength=0;bool discard=false;uint32_t lastByte=0;
uint32_t lastCycle=0,lastSample=0,lastFrame=0;
bool seenCycle=false,seenSample=false,validVoltage=false;
int16_t gridW=0,loadW=0,voltage=0;uint16_t totalWh=0;
bool actualDiversion=false;
uint32_t autoWh=0,boostWh=0;
uint32_t autoFraction=0,boostFraction=0;
uint32_t lastEnergyLog=0;
bool energyLogStarted=false;
void accumulateEnergy(int16_t measuredW,uint32_t periodMs) {
  // Estimation Wh par CT2 sur la fenetre de datalog. PAS une mesure de facturation.
  // Ne compter que les intervalles qualifies, avec puissance positive plausible.
  if(!validVoltage || measuredW<=0 || measuredW>6000 || periodMs>6500UL) return;
  uint32_t* whole=nullptr;uint32_t* fraction=nullptr;
  if(ctrl.mode==Mk2::Mode::AUTO) {whole=&autoWh;fraction=&autoFraction;}
  else if(ctrl.mode==Mk2::Mode::BOOST) {whole=&boostWh;fraction=&boostFraction;}
  else return;
  const uint32_t sum=*fraction+static_cast<uint32_t>(measuredW)*periodMs;
  *whole+=sum/3600000UL;
  *fraction=sum%3600000UL;
}
void resetRx(){rxLength=0;discard=false;}
const char* modeName(){switch(ctrl.mode){case Mk2::Mode::AUTO:return "AUTO";case Mk2::Mode::BOOST:return "BOOST";default:return "STOP";}}
bool ready(uint32_t now) {
  // Les mesures ne sont considerees fraiches que pendant 8s (datalog toutes 5s).
  // La presence du 50Hz est confirmee independamment par les evenements de cycle.
  return seenSample && validVoltage && seenCycle &&
    static_cast<uint32_t>(now-lastSample)<8000UL &&
    static_cast<uint32_t>(now-lastCycle)<150UL;
}
void updateShared(uint32_t now) {
  ctrl.tick(now);
  // Un BOOST ne reste pas arme si la source de mesure devient invalide.
  if(ctrl.mode==Mk2::Mode::BOOST && !ready(now)) ctrl.resetModes();
  // Ordre de publication : interdire d'abord, publier ensuite mode et duty.
  Mk2State::ready=false;
  Mk2State::mode=static_cast<uint8_t>(ctrl.mode);
  Mk2State::dutyPct=ctrl.dutyPercent();
  const bool valid=ready(now);
  Mk2State::ready=valid;
  // D4 de la Rev2.1a est ACTIVE-BAS. STOP et defaut coupent tout de suite.
  if(!valid || ctrl.mode==Mk2::Mode::STOP) digitalWrite(4,HIGH);
}
bool unsignedNumber(const char* s,uint16_t max,uint16_t& out) {
  if(!*s) return false;
  uint32_t val=0;
  for(;*s;++s) {if(*s<'0'||*s>'9')return false;val=val*10+(*s-'0');if(val>max)return false;}
  out=static_cast<uint16_t>(val);return true;
}
void printModeAck(){Serial.print(F("@ACK MODE "));Serial.println(modeName());}
void diag() {
  // Plusieurs lignes courtes pour ne pas saturer le tampon du Nano MAITRE.
  const uint32_t now=millis();
  Serial.print(F("@DIAG MODE="));Serial.print(modeName());
  Serial.print(F(" MEASURE="));Serial.print(ready(now)?1U:0U);
  Serial.print(F(" LIMIT_PCT="));Serial.print(ctrl.limitPct);
  Serial.print(F(" BOOST_PCT="));Serial.print(ctrl.mode==Mk2::Mode::BOOST?ctrl.boostPercent:0U);Serial.println("");
  Serial.print(F("@DIAG DUTY_PCT="));Serial.print(ready(now)?ctrl.dutyPercent():0U);
  Serial.print(F(" REQ_ON_LAST50="));Serial.print(Mk2State::last50On);
  Serial.print(F(" BOOST_REMAIN_S="));Serial.print((ctrl.remainingMs(now)+999UL)/1000UL);Serial.println("");
#ifdef MK2_ALLOW_TRIAC_OUTPUT
  Serial.print(F("@DIAG D3=DISABLED D4=ACTIVE_LOW OUTPUT=POWER"));
#else
  Serial.print(F("@DIAG D3=DISABLED D4=HIGH OUTPUT=REVIEW_OFF"));
#endif
  Serial.print(F(" WAIT="));Serial.println(Mk2Wait::name(selectedWaitStyle));
}
void frame() {
  const uint32_t now=millis();
  // V2 legacy : champs fixes pour l'ESP existant, mais les champs Watts de
  // configuration sont MIS A ZERO (inconnus), jamais remplaces par des %.
  // Le mode et duty_pct restent transmis; le BOOST en % exige un ESP adapte.
  char payload[100];
  const uint8_t flags=static_cast<uint8_t>(!ready(now)?1:0);
  const unsigned mode=static_cast<unsigned>(ctrl.mode);
  const uint8_t duty=ready(now)?ctrl.dutyPercent():0;
  const int n=snprintf(payload,sizeof(payload),
    "MK2,2,%u,%d,%d,%lu,%lu,0,%d,%u,%u,%u,0,%u",mode,(int)gridW,
    (int)loadW,static_cast<unsigned long>(autoWh),static_cast<unsigned long>(boostWh),
    (int)voltage,0U,
    (unsigned)duty,0U,(unsigned)flags);
  if(n<=0 || n>=static_cast<int>(sizeof(payload)))return;
  uint8_t sum=0;for(int i=0;i<n;++i)sum^=static_cast<uint8_t>(payload[i]);
  Serial.write('$');Serial.print(payload);Serial.write('*');
  if(sum<16)Serial.write('0');
  Serial.println(sum,HEX);
}
void handle(const char *cmd) {
  if(!strcmp(cmd,"@PING")){Serial.println(F("@PONG"));return;}
  if(!strcmp(cmd,"@VERSION")){Serial.println(F("@VERSION MK2_PV_ROUTER_V0_4_2"));return;}
  if(!strcmp(cmd,"@HELP")){
    Serial.println(F("@HELP PING VERSION HELP STATUS DIAG MODE AUTO MODE STOP"));
    Serial.println(F("@HELP LIMIT <PCT> BOOST <PCT> [MIN] BOOST OFF"));
    Serial.println(F("@HELP WAIT WAIT <0..3> WAIT TEST WAIT TEST OFF"));
    Serial.println(F("@HELP CAL CAL SET V|GRID|CT2 <GAIN_650..1500>"));
    Serial.println(F("@HELP CAL V <dV> CAL GRID <W> CAL CT2 <W> CAL RESET"));return;
  }
  if(!strcmp(cmd,"@CAL")) {
    Serial.print(F("@CAL V=")); Serial.print(Mk2Calibration::voltageGain());
    Serial.print(F(" GRID=")); Serial.print(Mk2Calibration::gridGain());
    Serial.print(F(" CT2=")); Serial.println(Mk2Calibration::ct2Gain());
    Serial.print(F("@CAL RAW_V_CENTI=")); Serial.print(Mk2Calibration::rawVoltage());
    Serial.print(F(" RAW_GRID_W=")); Serial.print(Mk2Calibration::rawGrid());
    Serial.print(F(" RAW_CT2_W=")); Serial.println(Mk2Calibration::rawCt2());
    return;
  }
  if(!strncmp(cmd,"@CAL SET ",9)) {
    const char *args = cmd + 9;
    const char *space = strchr(args, ' ');
    if(!space) {Serial.println(F("@ERR CAL_FORMAT")); return;}
    const size_t n = static_cast<size_t>(space - args);
    char channel[8]{};
    if(!n || n >= sizeof(channel)) {Serial.println(F("@ERR CAL_FORMAT")); return;}
    memcpy(channel, args, n);
    uint16_t gain = 0;
    if(!unsignedNumber(space+1,1500,gain) || gain < 650) {
      Serial.println(F("@ERR CAL_GAIN_650_1500")); return;
    }
    const char ch = !strcmp(channel,"V") ? 'V' :
      !strcmp(channel,"GRID") ? 'G' : !strcmp(channel,"CT2") ? 'C' : '?';
    if(!Mk2Calibration::setGain(ch,gain)) {
      Serial.println(F("@ERR CAL_CHANNEL")); return;
    }
    Serial.print(F("@ACK CAL SET ")); Serial.print(channel);
    Serial.print('='); Serial.println(gain);
    return;
  }
  if(!strcmp(cmd,"@CAL RESET")) {
    Mk2Calibration::reset(); Serial.println(F("@ACK CAL RESET")); return;
  }
  if(!strncmp(cmd,"@CAL ",5)) {
    const char *args = cmd+5;
    const char *space = strchr(args,' ');
    if(!space) { Serial.println(F("@ERR CAL_FORMAT")); return; }
    char channel[8]{};
    const size_t count=static_cast<size_t>(space-args);
    if(count==0 || count>=sizeof(channel)) { Serial.println(F("@ERR CAL_FORMAT")); return; }
    memcpy(channel,args,count);
    uint16_t reference=0;
    if(!unsignedNumber(space+1,10000,reference)) { Serial.println(F("@ERR CAL_REFERENCE")); return; }
    const bool ok = !strcmp(channel,"V") ? Mk2Calibration::calibrateVoltage(reference)
      : !strcmp(channel,"GRID") ? Mk2Calibration::calibrateGrid(reference)
      : !strcmp(channel,"CT2") ? Mk2Calibration::calibrateCt2(reference) : false;
    if(ok) { Serial.print(F("@ACK CAL ")); Serial.println(channel); }
    else Serial.println(F("@ERR CAL_REFERENCE_OR_MEASUREMENT"));
    return;
  }
  if(!strcmp(cmd,"@WAIT")){printWait();return;}
  if(!strcmp(cmd,"@WAIT TEST")){
    previewSince=millis();previewEnabled=true;
    Serial.println(F("@ACK WAIT PREVIEW_20S"));return;
  }
  if(!strcmp(cmd,"@WAIT TEST OFF")){
    previewEnabled=false;Serial.println(F("@ACK WAIT PREVIEW_OFF"));return;
  }
  if(!strncmp(cmd,"@WAIT ",6)){
    uint16_t style=0;
    if(!unsignedNumber(cmd+6,3,style)){
      Serial.println(F("@ERR WAIT_STYLE_0_3"));return;
    }
    selectedWaitStyle=static_cast<uint8_t>(style);
    saveWait();printWait();return;
  }
  if(!strcmp(cmd,"@DIAG")){diag();return;}
  if(!strcmp(cmd,"@STATUS")){if(seenSample)frame();else Serial.println(F("@WAIT MEASUREMENT"));return;}
  if(!strcmp(cmd,"@MODE AUTO")){ctrl.resetModes();updateShared(millis());printModeAck();return;}
  if(!strcmp(cmd,"@MODE STOP")){ctrl.mode=Mk2::Mode::STOP;updateShared(millis());printModeAck();return;}
  if(!strcmp(cmd,"@BOOST OFF")){ctrl.resetModes();updateShared(millis());Serial.println(F("@ACK BOOST OFF"));return;}
  if(!strncmp(cmd,"@LIMIT ",7)) {
    uint16_t pct=0;
    if(!unsignedNumber(cmd+7,100,pct) || !ctrl.setLimitPercent(pct)) {
      Serial.println(F("@ERR LIMIT_PERCENT_0_100"));return;
    }
    save();updateShared(millis());Serial.println(F("@ACK LIMIT PERCENT APPLIED"));return;
  }
  if(!strncmp(cmd,"@BOOST ",7)) {
    const char *param=cmd+7;const char *space=strchr(param,' ');
    uint16_t pct=0,mins=0;
    if(space) {
      char first[6];const size_t len=static_cast<size_t>(space-param);
      if(len==0 || len>=sizeof(first)) {Serial.println(F("@ERR ARG"));return;}
      memcpy(first,param,len);first[len]=0;
      if(!unsignedNumber(first,100,pct) || !unsignedNumber(space+1,120,mins)
          || pct==0 || mins==0) {Serial.println(F("@ERR BOOST_PERCENT_1_100_MIN_1_120"));return;}
      if(!ready(millis())) {Serial.println(F("@ERR NO_MEASUREMENT"));return;}
      ctrl.boostPct(pct,mins,millis());
      updateShared(millis());Serial.println(F("@ACK BOOST PERCENT TIMED"));return;
    }
    // Variante bail de 30s : POURCENT, PAS WATTS. Mettre a jour l'ESP.
    if(!unsignedNumber(param,100,pct) || pct==0) {
      Serial.println(F("@ERR BOOST_PERCENT_1_100"));return;
    }
    if(!ready(millis())) {Serial.println(F("@ERR NO_MEASUREMENT"));return;}
    ctrl.boostLeasePct(pct,millis());
    updateShared(millis());Serial.println(F("@ACK BOOST PERCENT LEASE_30S"));return;
  }
  if(!strncmp(cmd,"@HEATER",7)) {
    Serial.println(F("@ERR OBSOLETE USE_LIMIT_PERCENT"));return;
  }
  if(!strcmp(cmd,"@MODE BOOST") || !strcmp(cmd,"@BOOST")) {Serial.println(F("@ERR BOOST_ARGS_REQUIRED"));return;}
  if(!strncmp(cmd,"@TEMP",5)||!strncmp(cmd,"@TARGET",7)) {Serial.println(F("@ERR ESP_ONLY"));return;}
  Serial.println(F("@ERR UNKNOWN"));
}
}
void begin() {
  Mk2Calibration::begin();
  ctrl=Mk2::Controller{};restore();restoreWait();ctrl.resetModes();
  previewEnabled=false;previewSince=0;
  seenCycle=false;seenSample=false;validVoltage=false;lastCycle=0;lastSample=0;
  energyLogStarted=false;autoWh=0;boostWh=0;autoFraction=0;boostFraction=0;
  Mk2State::countOn=0;Mk2State::countTotal=0;Mk2State::last50On=0;
  resetRx();updateShared(millis());
  Serial.println(F("@READY MK2_PV_ROUTER_V0_4_2 MODE=AUTO"));
}
void poll() {
  const uint32_t now=millis();updateShared(now);
  if (previewEnabled && static_cast<uint32_t>(now-previewSince)>=20000UL)
    previewEnabled=false;
  if(rxLength&&static_cast<uint32_t>(now-lastByte)>250UL)resetRx();
  uint8_t budget=16;
  while(budget-- && Serial.available()>0) {
    const char c=static_cast<char>(Serial.read());lastByte=millis();
    if(c=='\r')continue;
    if(c=='\n'){if(!discard&&rxLength){rx[rxLength]=0;handle(rx);}resetRx();continue;}
    if(c=='@'){resetRx();rx[rxLength++]=c;continue;}
    if(!rxLength||discard)continue;
    if(rxLength<sizeof(rx)-1)rx[rxLength++]=c;else {rxLength=0;discard=true;}
  }
}
void mainsCycleSeen() {seenCycle=true;lastCycle=millis();updateShared(lastCycle);}
void onTelemetry(int16_t g,int16_t l,int16_t v,uint16_t wh,bool div,uint16_t sampleSets) {
  gridW=g;loadW=l;voltage=v;totalWh=wh;actualDiversion=div;
  // Pas de declaration de mesure exploitable si tension hors domaine ou acquisition vide.
  validVoltage=(v>=19000 && v<=25500 && sampleSets>=100);
  const uint32_t now=millis();
  if(energyLogStarted && validVoltage) accumulateEnergy(l,now-lastEnergyLog);
  energyLogStarted=true;lastEnergyLog=now;
  seenSample=true;lastSample=now;updateShared(lastSample);
  if(static_cast<uint32_t>(lastSample-lastFrame)>=5000UL) {lastFrame=lastSample;frame();}
}
Mk2::Mode mode(){return ctrl.mode;}
uint8_t waitStyle(){return selectedWaitStyle;}
bool waitPreviewActive(){
  return previewEnabled && static_cast<uint32_t>(millis()-previewSince)<20000UL;
}
}
