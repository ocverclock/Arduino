#pragma once
#include <stdint.h>
// Etats et compteurs sur un octet : lectures/ecritures atomiques sur AVR 8 bits.
namespace Mk2State {
inline volatile bool ready{false};
inline volatile uint8_t mode{0};
inline volatile uint8_t dutyPct{100};
// Une fenetre = 50 periodes secteur (1s a 50 Hz). Les chiffres designent
// la commande demandee, PAS une mesure de puissance effectivement fournie.
inline volatile uint8_t countOn{0};
inline volatile uint8_t countTotal{0};
inline volatile uint8_t last50On{0};
}
