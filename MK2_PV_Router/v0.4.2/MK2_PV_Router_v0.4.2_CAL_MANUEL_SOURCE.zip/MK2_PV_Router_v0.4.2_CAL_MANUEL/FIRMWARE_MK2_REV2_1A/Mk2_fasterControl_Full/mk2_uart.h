#pragma once
#include <Arduino.h>
#include "mk2_core.h"
namespace Mk2Uart {
void begin();
void poll();
void mainsCycleSeen();
void onTelemetry(int16_t gridW,int16_t loadW,int16_t voltageCentiV,uint16_t totalWh,bool diversionEnabled,uint16_t sampleSets);
Mk2::Mode mode();
uint8_t waitStyle();
bool waitPreviewActive();
}
