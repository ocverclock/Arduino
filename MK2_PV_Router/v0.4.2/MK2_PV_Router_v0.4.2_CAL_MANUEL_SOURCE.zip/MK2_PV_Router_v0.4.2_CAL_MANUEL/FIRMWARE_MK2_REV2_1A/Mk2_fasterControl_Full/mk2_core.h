#pragma once
// MK2 PV Router v0.3.8 : pilotage en pourcentage de periodes 50 Hz.
// Ce module n'a besoin ni de la puissance nominale du ballon ni de watts.
#include <stdint.h>
namespace Mk2 {
enum class Mode : uint8_t { AUTO=0, BOOST=1, STOP=2 };
struct Controller {
  Mode mode{Mode::AUTO};
  uint8_t limitPct{100};       // 0=aucune periode, 100=toutes autorisees
  uint8_t boostPercent{0};    // fraction des periodes du reseau demandee
  uint32_t boostSince{0};
  uint32_t boostDuration{0};
  void resetModes() { mode=Mode::AUTO; boostPercent=0; boostDuration=0; }
  void tick(uint32_t now) {
    if (mode==Mode::BOOST && static_cast<uint32_t>(now-boostSince)>=boostDuration)
      resetModes();
  }
  bool setLimitPercent(uint16_t pct) {
    if (pct>100) return false;
    limitPct=static_cast<uint8_t>(pct); return true;
  }
  bool boostPct(uint16_t pct, uint16_t minutes, uint32_t now) {
    if (pct==0 || pct>100 || minutes==0 || minutes>120) return false;
    mode=Mode::BOOST; boostPercent=static_cast<uint8_t>(pct);
    boostSince=now; boostDuration=static_cast<uint32_t>(minutes)*60000UL;
    return true;
  }
  bool boostLeasePct(uint16_t pct, uint32_t now) {
    if (pct==0 || pct>100) return false;
    mode=Mode::BOOST; boostPercent=static_cast<uint8_t>(pct);
    boostSince=now; boostDuration=30000UL; return true;
  }
  uint8_t dutyPercent() const {
    if (mode==Mode::STOP) return 0;
    if (mode==Mode::BOOST && boostPercent<limitPct) return boostPercent;
    return limitPct;
  }
  uint32_t remainingMs(uint32_t now) const {
    if (mode!=Mode::BOOST) return 0;
    const uint32_t elapsed=static_cast<uint32_t>(now-boostSince);
    return elapsed>=boostDuration ? 0 : boostDuration-elapsed;
  }
};
// Distributeur de creneaux : une decision POUR CHAQUE periode secteur,
// sans periode PWM, et non seulement lorsqu'AUTO demande une chauffe.
// Sur exactement 100 periodes, un objectif de p% ouvre p creneaux.
struct WholeCycleGate {
  uint8_t balance{0};
  void reset() {balance=0;}
  bool next(uint8_t percent) {
    if(percent==0) {balance=0;return false;}
    if(percent>=100) {balance=0;return true;}
    const uint16_t accumulated=static_cast<uint16_t>(balance)+percent;
    if(accumulated>=100) {
      balance=static_cast<uint8_t>(accumulated-100);return true;
    }
    balance=static_cast<uint8_t>(accumulated);return false;
  }
};
} // namespace Mk2
