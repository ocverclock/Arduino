#pragma once
#include <stdint.h>
// MK2 PV Router — animations de veille solaire pour afficheur BCD 74HC4543.
// Aucun glyphe non-BCD : seules les valeurs 0..9, 10 (blanc) et le bit DP sont utilisees.
namespace Mk2Wait {
inline constexpr uint8_t styles = 4;
inline constexpr uint8_t blank = 10;
inline constexpr uint8_t dot = 0x80;
inline const char *name(uint8_t style) {
  switch (style) {
    case 0: return "DOT";
    case 1: return "PULSE";
    case 2: return "CHASE";
    case 3: return "COUNT";
    default: return "UNKNOWN";
  }
}
inline void render(uint8_t style, uint8_t step, uint8_t out[4]) {
  for (uint8_t i = 0; i < 4; ++i) out[i] = blank;
  switch (style) {
    case 0:  // point unique tournant sur les quatre afficheurs
      out[step % 4] = blank | dot;
      break;
    case 1:  // quatre points qui respirent en alternance ON/OFF
      if ((step & 1U) == 0) for (uint8_t i = 0; i < 4; ++i) out[i] |= dot;
      break;
    case 2:  // chiffre 0 mobile, trajet aller-retour 0-1-2-3-2-1
      { const uint8_t pos = static_cast<uint8_t>(step % 6);
        out[pos < 4 ? pos : static_cast<uint8_t>(6-pos)] = 0;
      }
      break;
    case 3:  // compteur cyclique 0001..0004, chiffres BCD garanties
      out[0] = 0; out[1] = 0; out[2] = 0;
      out[3] = static_cast<uint8_t>(1U + step % 4);
      break;
    default:
      out[0] = blank | dot; break;
  }
}
} // namespace Mk2Wait
